package Service;

public interface IServiceUtilisateur <T>{
    T getUserById(int idUser);
}
